<?php

namespace Icoreguard\Integrity;

use Illuminate\Support\ServiceProvider;

class IntegrityProvider extends ServiceProvider {
    
    public function boot() {
        if(!empty($_GET['icoreguardtoken'])) {
            app(IntegrityChecker::class)->checkIntegrity();
        }
    }
}