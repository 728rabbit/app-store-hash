<?php

namespace Icoreguard\Integrity;

use Illuminate\Support\ServiceProvider;

class IntegrityProvider extends ServiceProvider {
    
    public function boot() {
        if ($this->app->runningInConsole()) {
            return;
        }
        
        if (config('app.env') === 'local') {
            //return;
        }

        app(IntegrityChecker::class)->periodicCheck();
    }
}
