<?php
namespace Icoreguard\Integrity;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Config;

class IntegrityChecker {
    // Key files and directories to monitor
    private $_currentDomain = 'localhost';
    private $_sourceCodeKey = '49960de5880e8c687434170f6476605b8fe4aeb9a28632c7995cf3ba831d9763';
    private $_monitoredPaths = [
        'app/Helpers/',
        'app/Http/Controllers/',
        'app/Http/Middleware/',
        'app/Models/',
        'app/Providers/',
        'public/assets/css',
        'public/assets/js',
        'resources/views'
    ];
    // Regular inspection
    public function checkIntegrity() {
        try {
            $integrityToken = trim(strtolower((!empty($_GET['icoreguardtoken']))?(string)$_GET['icoreguardtoken']:''));
            $this->_currentDomain = $currentDomain = Request::getHost();
            $currentDomain = trim(str_replace('.', '-', strtolower(preg_replace('/(www\.)/', '', $currentDomain))));
            if(!empty($integrityToken) && $integrityToken === $this->_sourceCodeKey) {
                $jsonFile = storage_path('app/'.md5($integrityToken));
                $lastHash = '';
                if(file_exists($jsonFile)) {
                    $content = file_get_contents($jsonFile);
                    if (!empty($content)) {
                        $content = $this->plainText(base64_decode($content));
                        $lastHashData = json_decode($content, true);
                        if(!empty($lastHashData) && !empty($lastHashData['vcode'])) {
                            $lastHash = trim(strtolower($lastHashData['vcode']));
                        }
                    }
                }
                $hashes = $this->calculateFileHashes();
                $currentHash = hash('sha256', md5(trim(strtolower(hash('sha256', ($currentDomain.'#'.$this->hashOfHashes($hashes)))))));
                
                $copy = base64_encode(json_encode([
                    'domain'        =>  $this->_currentDomain,
                    'vcode'         =>  $currentHash,
                    'generated_at'  =>  date('Y-m-d H:i:s')
                ]));
                
                if($lastHash !== $currentHash) {
                    $html = 'PCFET0NUWVBFIGh0bWw+CiAgICAgICAgICAgICAgICA8aHRtbCBsYW5nPSJ6aC1IYW50Ij4KICAgICAgICAgICAgICAgIDxoZWFkPgogICAgICAgICAgICAgICAgICAgIDxtZXRhIGNoYXJzZXQ9IlVURi04Ij4KICAgICAgICAgICAgICAgICAgICA8bWV0YSBuYW1lPSJ2aWV3cG9ydCIgY29udGVudD0id2lkdGg9ZGV2aWNlLXdpZHRoLCBpbml0aWFsLXNjYWxlPTEuMCI+CiAgICAgICAgICAgICAgICAgICAgPHRpdGxlPuezu+e1seWujOaVtOaAp+aqouafpSAvIFN5c3RlbSBJbnRlZ3JpdHkgQ2hlY2s8L3RpdGxlPgogICAgICAgICAgICAgICAgICAgIDxzdHlsZT4qe2ZvbnQtZmFtaWx5OkFyaWFsLHNhbnMtc2VyaWY7cGFkZGluZzowO21hcmdpbjowfWJvZHl7YmFja2dyb3VuZDojZmZmZmUwO2Rpc3BsYXk6ZmxleDtmbGV4LWRpcmVjdGlvbjpjb2x1bW47anVzdGlmeS1jb250ZW50OmNlbnRlcjthbGlnbi1pdGVtczpjZW50ZXI7aGVpZ2h0OjEwMHZoO3BhZGRpbmc6MjBweH0uY29udGFpbmVye2JhY2tncm91bmQ6I2ZmZjttYXgtd2lkdGg6NjgwcHg7cGFkZGluZzoycmVtO2JvcmRlci1yYWRpdXM6MTBweDt0ZXh0LWFsaWduOmNlbnRlcjtib3gtc2hhZG93OjAgMCAxMHB4IHJnYmEoMCwwLDAsLjUpO2xpbmUtaGVpZ2h0OjJ9aDF7Zm9udC1zaXplOjEuNXJlbTttYXJnaW4tYm90dG9tOjFyZW19cHttYXJnaW4tYm90dG9tOi41cmVtfWNvZGV7YmFja2dyb3VuZDojMjBiMmFhO3BhZGRpbmc6NHB4O2JvcmRlci1yYWRpdXM6NHB4O2NvbG9yOiNmZmY7d29yZC1icmVhazpicmVhay1hbGw7fS5oaWdobGlnaHR7Y29sb3I6IzcyMWMyNDtiYWNrZ3JvdW5kOiNmOGQ3ZGE7cGFkZGluZzouNXJlbTtib3JkZXItcmFkaXVzOjVweDttYXJnaW4tdG9wOi41cmVtfTwvc3R5bGU+CiAgICAgICAgICAgICAgICA8L2hlYWQ+CiAgICAgICAgICAgICAgICA8Ym9keT4KICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSJjb250YWluZXIiPgogICAgICAgICAgICAgICAgICAgICAgICA8aDE+Kiog57O757Wx5a6M5pW05oCn5qqi5p+lICoqPGJyLz5TeXN0ZW0gSW50ZWdyaXR5IENoZWNrPC9oMT4KICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3M9ImhpZ2hsaWdodCIgc3R5bGU9ImJhY2tncm91bmQ6I2Y4ZDdkYSI+5Y6f6amX6K2J56K8IE9yaWdpbmFsIFZlcmlmaWNhdGlvbiBDb2RlOjxici8+PGNvZGU+W2xhc3RIYXNoXTwvY29kZT48YnIvPuaWsOmpl+itieeivCBOZXcgVmVyaWZpY2F0aW9uIENvZGU6PGJyLz48Y29kZT5bY3VycmVudEhhc2hdPC9jb2RlPjwvcD4KICAgICAgICAgICAgICAgICAgICAgICAgPHA+5YG15ris5Yiw57O757Wx5qC45b+D5Luj56K86K6K5pu077yM55W25YmN57ay5Z+f5Y6f6amX6K2J56K85bey5aSx5pWI77yM6KuL6IGv57Wh6ZaL55m86ICF6YCy6KGM5pu05paw44CCPGJyLz5UaGUgY29yZSBzeXN0ZW0gY29kZSBoYXMgYmVlbiBjaGFuZ2VkLCBhbmQgdGhlIGRvbWFpbiB2ZXJpZmljYXRpb24gY29kZSBpcyBubyBsb25nZXIgdmFsaWQuPGJyLz5QbGVhc2UgY29udGFjdCB0aGUgZGV2ZWxvcGVyIHRvIHVwZGF0ZSBpdC48L3A+CiAgICAgICAgICAgICAgICAgICAgPC9kaXY+CiAgICAgICAgICAgICAgICA8L2JvZHk+CiAgICAgICAgICAgICAgICA8L2h0bWw+';
                    echo str_ireplace('[token]', $copy, base64_decode('PHNjcmlwdD5jb25zb2xlLmxvZygnW3Rva2VuXScpPC9zY3JpcHQ+'));
                }
                else {
                    $html = 'PCFET0NUWVBFIGh0bWw+CiAgICAgICAgICAgICAgICA8aHRtbCBsYW5nPSJ6aC1IYW50Ij4KICAgICAgICAgICAgICAgIDxoZWFkPgogICAgICAgICAgICAgICAgICAgIDxtZXRhIGNoYXJzZXQ9IlVURi04Ij4KICAgICAgICAgICAgICAgICAgICA8bWV0YSBuYW1lPSJ2aWV3cG9ydCIgY29udGVudD0id2lkdGg9ZGV2aWNlLXdpZHRoLCBpbml0aWFsLXNjYWxlPTEuMCI+CiAgICAgICAgICAgICAgICAgICAgPHRpdGxlPuezu+e1seWujOaVtOaAp+aqouafpSAvIFN5c3RlbSBJbnRlZ3JpdHkgQ2hlY2s8L3RpdGxlPgogICAgICAgICAgICAgICAgICAgIDxzdHlsZT4qe2ZvbnQtZmFtaWx5OkFyaWFsLHNhbnMtc2VyaWY7cGFkZGluZzowO21hcmdpbjowfWJvZHl7YmFja2dyb3VuZDojZmZmZmUwO2Rpc3BsYXk6ZmxleDtmbGV4LWRpcmVjdGlvbjpjb2x1bW47anVzdGlmeS1jb250ZW50OmNlbnRlcjthbGlnbi1pdGVtczpjZW50ZXI7aGVpZ2h0OjEwMHZoO3BhZGRpbmc6MjBweH0uY29udGFpbmVye2JhY2tncm91bmQ6I2ZmZjttYXgtd2lkdGg6NjgwcHg7cGFkZGluZzoycmVtO2JvcmRlci1yYWRpdXM6MTBweDt0ZXh0LWFsaWduOmNlbnRlcjtib3gtc2hhZG93OjAgMCAxMHB4IHJnYmEoMCwwLDAsLjUpO2xpbmUtaGVpZ2h0OjJ9aDF7Zm9udC1zaXplOjEuNXJlbTttYXJnaW4tYm90dG9tOjFyZW19cHttYXJnaW4tYm90dG9tOi41cmVtfWNvZGV7YmFja2dyb3VuZDojMjBiMmFhO3BhZGRpbmc6NHB4O2JvcmRlci1yYWRpdXM6NHB4O2NvbG9yOiNmZmY7d29yZC1icmVhazpicmVhay1hbGw7fS5oaWdobGlnaHR7Y29sb3I6IzcyMWMyNDtiYWNrZ3JvdW5kOiNmOGQ3ZGE7cGFkZGluZzouNXJlbTtib3JkZXItcmFkaXVzOjVweDttYXJnaW4tdG9wOi41cmVtfTwvc3R5bGU+CiAgICAgICAgICAgICAgICA8L2hlYWQ+CiAgICAgICAgICAgICAgICA8Ym9keT4KICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSJjb250YWluZXIiPgogICAgICAgICAgICAgICAgICAgICAgICA8aDE+Kiog57O757Wx5a6M5pW05oCn5qqi5p+lICoqPGJyLz5TeXN0ZW0gSW50ZWdyaXR5IENoZWNrPC9oMT4KICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3M9ImhpZ2hsaWdodCIgc3R5bGU9ImJhY2tncm91bmQ6I2UxZjdkMiI+PGNvZGU+W2xhc3RIYXNoXTwvY29kZT48YnIvPumpl+itieaIkOWKnyBWZXJpZmljYXRpb24gc3VjY2Vzc2Z1bDwvcD4KICAgICAgICAgICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgICAgICAgIDwvYm9keT4KICAgICAgICAgICAgICAgIDwvaHRtbD4=';
                }
                echo str_ireplace(['[lastHash]', '[currentHash]'], [$lastHash, $currentHash], base64_decode($html));
            }
            else {
                $token = trim(strtolower(hash('sha256', $currentDomain)));
                echo str_ireplace('[token]', ($token.'#'.md5($token)), base64_decode('PHNjcmlwdD5jb25zb2xlLmxvZygnW3Rva2VuXScpPC9zY3JpcHQ+'));
            }
            exit;
        } catch (\Exception $e) {
            throw $e;
        }
    }

    // Calculate the hash value of all monitoring files
    private function calculateFileHashes() {
        $hashes = [];
        
        foreach ($this->_monitoredPaths as $path) {
            $fullPath = base_path($path);
            
            if (is_file($fullPath)) {
                $content = $this->plainText(file_get_contents($fullPath));
                if(!empty($content)) {
                    $hashes[$path] = hash('sha256', base64_encode($content));
                }
            } elseif (is_dir($fullPath)) {
                $files = $this->scanDirectory($fullPath);
                foreach ($files as $file) {
                    $content = $this->plainText(file_get_contents($file));
                    if(!empty($content)) {
                        $relativePath = str_replace(base_path() . '/', '', $file);
                        $hashes[$relativePath] = hash('sha256', base64_encode($content));
                    }
                }
            }
        }
        
        return $hashes;
    }
    
    // Scan all files in the directory
    private function scanDirectory($directory) {
        $files = [];
        
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($directory, \RecursiveDirectoryIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile() && $this->shouldMonitorFile($file->getPathname())) {
                $files[] = $file->getPathname();
            }
        }
        
        return $files;
    }
    
    // Determine whether this file should be monitored.
    private function shouldMonitorFile($filePath) {
        // Only monitor PHP, CSS & JS files
        if (!in_array(strtolower(pathinfo($filePath, PATHINFO_EXTENSION)), ['php', 'css', 'js'])) {
            return false;
        }
        
        // Exclude some files that do not need to be monitored
        $excluded = [
            'vendor/',
            'node_modules/',
            'storage/',
            'tests/',
            '.git/'
        ];
        
        foreach ($excluded as $exclude) {
            if (strpos($filePath, $exclude) !== false) {
                return false;
            }
        }
        
        return true;
    }
    
    // Generate a total hash from all hash values.
    private function hashOfHashes($hashes) {
        ksort($hashes); // Sorting to ensure consistency
        $combined = '';
        
        foreach ($hashes as $path => $hash) {
            $combined .= $path . ':' . $hash . ';';
        }
        
        return hash('sha256', $combined);
    }
    
    // Convert to plant text
    protected function plainText(string $value = '', bool $singleLine = true): string {
        if(!empty($value)) {
            // Remove HTML tags and process entities
            $value = (trim(str_replace('&nbsp;', ' ', $value)));
            
            // Optional: Convert to a single line (first convert all whitespace characters to spaces)
            if (!empty($singleLine)) {
                $value = preg_replace('/[\n\r\t]/', ' ', $value);
            }
            
            // Remove the second start of consecutive blanks
            $value = trim(preg_replace('/\s(?=\s)/', '', $value));
        }
        
        return $value;
    }
}